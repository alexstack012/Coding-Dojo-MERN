import React from "react"

const Error = (props) => {
    return (
        <div>
            <p>These are not the droids you are looking for</p>
            <img src="https://i.gifer.com/18UX.gif" alt="error messge"></img>
        </div>
    )
}
export default Error