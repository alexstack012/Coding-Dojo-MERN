import React from "react";

import Form from "./Form";

export default () => (
    <>
        <Form />
    </>
);